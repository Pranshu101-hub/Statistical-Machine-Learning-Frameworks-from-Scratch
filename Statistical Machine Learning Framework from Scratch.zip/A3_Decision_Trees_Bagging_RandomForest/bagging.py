import os
import numpy
import matplotlib.pyplot as mtplot
from urllib.request import urlretrieve

#load data
def load_mnist():
    d = "mnist.numpyz"
    if not os.path.exists(d):
        url = "https://s3.amazonaws.com/img-datasets/mnist.npz"
        print("Downloading data from", url, "...")
        urlretrieve(url, d)
    
    f = numpy.load(d)
    x_train, y_train = f['x_train'], f['y_train']
    x_test,  y_test  = f['x_test'],  f['y_test']
    f.close()
    return (x_train, y_train), (x_test, y_test)

print("loading data...")
(x_train_, y_train_), (x_test_, y_test_) = load_mnist()

#preprocess
def preprocess_data(x_data, y_data):
    filt = numpy.isin(y_data, [0, 1, 2]) # filter 0,1,2
    x_f= x_data[filt]
    y_f= y_data[filt]
    x_flat = x_f.reshape(x_f.shape[0], -1) #28x28 to 784 flat
    x_norm = x_flat.astype(numpy.float64) / 255.0 #norm to [0,1]
    return x_norm, y_f

X_train, y_train = preprocess_data(x_train_, y_train_)  # (N_train, 784)
X_test,  y_test  = preprocess_data(x_test_,  y_test_)   # (N_test,  784)

#pca 
def pca(X, n):
    mew = numpy.mean(X, axis=0, keepdims=True) # mean of each feature
    Xc = X - mew #centre the data
    N = X.shape[0]
    S = (Xc.T @ Xc) / (N - 1) # cov matrix

    eigval, eigvec = numpy.linalg.eigh(S) # eig for symmetric matrix
    eigval = numpy.real(eigval)
    eigvec = numpy.real(eigvec)
    i = numpy.argsort(eigval)[::-1] # sort biggest first
    eigvec = eigvec[:, i]
    Up = eigvec[:, :n] # top n eigenvectors
    Y  = Xc @ Up # N, n
    return Y, Up, mew

print("running PCA to 10 dims...")
X_tr_pca, Up, mew_train = pca(X_train, n=10)
X_te_pca = (X_test - mew_train) @ Up # project test with same PCA

classes = numpy.array([0, 1, 2])
N = len(X_tr_pca) # total training samples

#gini helper functions  
def gini(labels): # gini index = 1 - sum(p_k^2) for each class k
    if len(labels) == 0:
        return 0 #pure = 0, if no samples
    n = len(labels)
    su = 0
    for c in classes:
        count = numpy.sum(labels == c)  
        p_c = count / n
        su += (p_c ** 2)     
    return 1-su        

def weighted_gini(left_labels, right_labels):
    # weighted average of gini in left and right child
    n = len(left_labels) + len(right_labels)
    return (len(left_labels) / n) * gini(left_labels) + \
           (len(right_labels) / n) * gini(right_labels)

def majority_class(labels):
    # return the class that appears most often
    counts = {c: numpy.sum(labels == c) for c in classes}
    return max(counts, key=counts.get)

#find the best split across given features  
def split_best(X, y, feature_subset=None):
    n_feat = X.shape[1]
    feat_list = range(n_feat) if feature_subset is None else feature_subset
    best_g, best_f, best_t = numpy.inf, None, None
    for f in feat_list:
        t = numpy.median(X[:, f]) # use median as threshold
        left = y[X[:, f] <= t]
        right= y[X[:, f] >t]
        g = weighted_gini(left, right) # compute weighted gini
        if g < best_g:
            best_g, best_f, best_t = g, f, t # keep best so far
    return best_f, best_t, best_g

#build a tree with 2 splits (3 leaf regions)
def build_tree(X, y, feature_subset=None):
    f1, t1, g1 = split_best(X, y, feature_subset)
    lm = X[:, f1] <= t1 #left filt
    X_l, y_l = X[lm],  y[lm] 
    X_r, y_r = X[~lm], y[~lm] 

    f2, t2, g2 = split_best(X_l, y_l, feature_subset)

    if len(y_r) > 0:
        leaf_right = majority_class(y_r)
    else:
        leaf_right = classes[0]

    if numpy.any(X_l[:, f2] <= t2):
        labels_ll = y_l[X_l[:, f2] <= t2]
        leaf_ll = majority_class(labels_ll)
    else:
        leaf_ll = classes[0]

    if numpy.any(X_l[:, f2] > t2):
        labels_lr = y_l[X_l[:, f2] > t2]
        leaf_lr = majority_class(labels_lr)
    else:
        leaf_lr = classes[0]

    return (f1, t1, f2, t2, leaf_right, leaf_ll, leaf_lr)

def predict_tree(tree, X):
    f1, t1, f2, t2, leaf_right, leaf_ll, leaf_lr = tree
    preds   = numpy.empty(len(X), dtype=int)
    r_filt  = X[:, f1] > t1 
    l_filt  = ~r_filt 
    ll_filt = l_filt & (X[:, f2] <= t2) 
    lr_filt = l_filt & (X[:, f2] >  t2) 
    preds[r_filt]  = leaf_right
    preds[ll_filt] = leaf_ll
    preds[lr_filt] = leaf_lr
    return preds

# train and evaluate single tree 
print("building single decision tree...")
tree1 = build_tree(X_tr_pca, y_train)
f1, t1, f2, t2, _, _, _ = tree1
print("root split -> feature", f1, ", threshold", round(t1, 4))
print("second split -> feature", f2, "(3rd dim index 2), threshold", round(t2, 4))

test_preds  = predict_tree(tree1, X_te_pca)
overall_acc = numpy.mean(test_preds == y_test)
print("\nsingle tree - overall test accuracy:", round(overall_acc*100, 2), "%")
for c in classes:
    filt = y_test == c
    acc  = numpy.mean(test_preds[filt] == c)
    print(" class", c, "accuracy:", round(acc*100, 2), "%")

#bagging: 5 bootstrap trees
print("\nbagging with 5 trees...")
rng = numpy.random.RandomState(67) 
n_trees = 5
bagged_trees = []
ooberr = []
boot_idx_all = []

for i in range(n_trees):
    boot_idx = rng.randint(0, N, size=N)
    oob_idx= numpy.setdiff1d(numpy.arange(N), boot_idx)
    X_b, y_b = X_tr_pca[boot_idx], y_train[boot_idx]
    tree_b= build_tree(X_b, y_b)
    bagged_trees.append(tree_b)
    boot_idx_all.append(boot_idx)
    oob_preds = predict_tree(tree_b, X_tr_pca[oob_idx])
    oob= 1 - numpy.mean(oob_preds == y_train[oob_idx])
    ooberr.append(oob)
    print("tree", i+1, ": oob error =", round(oob, 4))

print("average OOB error:", round(numpy.mean(ooberr), 4))

# majority vote
all_preds = numpy.column_stack([predict_tree(t, X_te_pca) for t in bagged_trees])
bag_preds = numpy.array([numpy.bincount(all_preds[i], minlength=3).argmax() for i in range(len(X_te_pca))])
bag_acc   = numpy.mean(bag_preds == y_test)
print("\nbagging - overall test accuracy:", round(bag_acc*100, 2), "%")
for c in classes:
    filt = y_test == c
    acc  = numpy.mean(bag_preds[filt] == c)
    print(" class", c, "accuracy:", round(acc*100, 2), "%")

#random forest
print("\nrandom forest...")
rng2 = numpy.random.RandomState(42)
for k in [2,3,4,5,8]:
    rf_trees  = []
    rf_oob    = []
    rng_k     = numpy.random.RandomState(k)
    for b in range(n_trees):
        boot_idx = boot_idx_all[b]
        oob_idx  = numpy.setdiff1d(numpy.arange(N), boot_idx)
        X_b, y_b = X_tr_pca[boot_idx], y_train[boot_idx]
        #first split
        feat1 = rng_k.choice(10, size=k, replace=False)
        f1_, t1_, _ = split_best(X_b, y_b, feat1)
        lm = X_b[:, f1_] <= t1_
        X_l, y_l = X_b[lm],  y_b[lm]
        X_r, y_r = X_b[~lm], y_b[~lm]


        feat2 = rng_k.choice(10, size=k, replace=False)  #second split on lef t child
        f2_, t2_, _ = split_best(X_l, y_l, feat2)
        
        # right leaf
        if len(y_r) > 0:
            leaf_right = majority_class(y_r)
        else:
            leaf_right = classes[0]

        #left left
        mask_ll = X_l[:, f2_] <= t2_
        if numpy.any(mask_ll):
            labels_ll = y_l[mask_ll]
            leaf_ll = majority_class(labels_ll)
        else:
            leaf_ll = classes[0]

        # left right
        mask_lr = X_l[:, f2_] > t2_
        if numpy.any(mask_lr):
            labels_lr = y_l[mask_lr]
            leaf_lr = majority_class(labels_lr)
        else:
            leaf_lr = classes[0]
        tree_rf = (f1_, t1_, f2_, t2_, leaf_right, leaf_ll, leaf_lr)
        rf_trees.append(tree_rf)
        
        oob_preds = predict_tree(tree_rf, X_tr_pca[oob_idx]) # oob error on training data not used for this tree
        rf_oob.append(1 - numpy.mean(oob_preds == y_train[oob_idx]))

    avg_oob = numpy.mean(rf_oob)
    
    # Final aggregation and reporting
    rf_all = numpy.column_stack([predict_tree(t, X_te_pca) for t in rf_trees])
    rf_final = numpy.array([numpy.bincount(rf_all[i], minlength=3).argmax() for i in range(len(X_te_pca))])
    rf_acc = numpy.mean(rf_final == y_test)
    
    print("\nrandom forest (k=", k, ") - avg OOB error:", round(avg_oob, 4), ", test acc:", round(rf_acc*100, 2), "%")
    for c in classes:
        filt = y_test == c
        acc  = numpy.mean(rf_final[filt] == c)
        print(" class", c, "accuracy:", round(acc*100, 2), "%")