import numpy
import matplotlib.pyplot as mtplot

# generate dataset
def make_dataset(cov_scale, n_per_class=200, seed=42):
    rng= numpy.random.RandomState(seed)
    mu_neg = numpy.array([-3.0, -3.0]) # mean for class -1
    mu_pos = numpy.array([ 3.0,  3.0]) # mean for class +1
    cov= cov_scale * numpy.eye(2)   # covariance = cov_scale * I

    X_neg = rng.multivariate_normal(mu_neg, cov, n_per_class) # (200, 2) samples for class -1
    X_pos = rng.multivariate_normal(mu_pos, cov, n_per_class) # (200, 2) samples for class +1

    X = numpy.vstack([X_neg, X_pos])# stack into (400, 2)
    y = numpy.hstack([numpy.full(n_per_class, -1),numpy.full(n_per_class,  1)]) #labels: first 200 are -1, next 200 are +1
    return X, y

X_A, y_A = make_dataset(cov_scale=1) # dataset A: cov = I
X_B, y_B = make_dataset(cov_scale=3) # dataset B: cov = 3I
print("dataset A:", X_A.shape, "| dataset B:", X_B.shape)

# 70-30 train/test split
def split_data(X, y, test_ratio=0.3, seed=42):
    rng   = numpy.random.RandomState(seed)
    n     = len(y)
    idx   = rng.permutation(n) # random permutation of indices
    split = int(n * (1 - test_ratio)) # 70% train, 30% test
    tr_idx, te_idx = idx[:split], idx[split:]
    return X[tr_idx], X[te_idx], y[tr_idx], y[te_idx]

X_A_tr, X_A_te, y_A_tr, y_A_te = split_data(X_A, y_A) # dataset A split
X_B_tr, X_B_te, y_B_tr, y_B_te = split_data(X_B, y_B) # dataset B split
print("A -> train:", X_A_tr.shape, ", test:", X_A_te.shape)
print("B -> train:", X_B_tr.shape, ", test:", X_B_te.shape)

# rosenblatt perceptron
def perceptron(X_train, y_train, X_test, y_test, eta=0.01, max_epochs=300):
    n, d = X_train.shape
    w = numpy.zeros(d)  # initialise weights to zero
    b = 0.0 # initialise bias to zero   

    misc_per_epoch = [] # misclassified count per epoch
    conv_epoch = None  # epoch where convergence happens (if at all)

    for epoch in range(1, max_epochs + 1):
        n_wrong = 0 # count misclassified this epoch

        for i in range(n):
            xi = X_train[i]
            yi = y_train[i]
            act = numpy.dot(w, xi) + b #activation = w^T xi + b
            if yi * act <= 0: # misclassified: y*(w^T x + b) <= 0
                w += eta * yi * xi #w + eta * yi * xi
                b += eta * yi #b + eta * yi
                n_wrong += 1

        misc_per_epoch.append(n_wrong)

        if n_wrong == 0: # early stopping: full epoch with no mistakes
            conv_epoch = epoch
            print("  converged at epoch", epoch)
            break

    test_preds = numpy.sign(X_test @ w + b) # predict on test set
    test_preds[test_preds == 0] = 1 # sign(0) edge case -> assign +1
    test_acc = numpy.mean(test_preds == y_test)

    return w, b, misc_per_epoch, conv_epoch, test_acc

# run on both datasets
print("\ndataset A (cov=I, well separated):")
w_A, b_A, misc_A, conv_A, acc_A = perceptron(X_A_tr, y_A_tr, X_A_te, y_A_te, eta=0.01)
print("convergence epoch:", conv_A)
print("test accuracy:", (acc_A, 4))

print("\ndataset B (cov=3I, more overlap):")
w_B, b_B, misc_B, conv_B, acc_B = perceptron(X_B_tr, y_B_tr, X_B_te, y_B_te, eta=0.01)
print("convergence epoch:", conv_B)
print("test accuracy:", (acc_B, 4))

# plot misclassified per epoch
fig, axes = mtplot.subplots(1, 2, figsize=(12, 5))

axes[0].plot(range(1, len(misc_A) + 1), misc_A, color='steelblue', linewidth=1.5) # misclass curve A
if conv_A:
    axes[0].axvline(conv_A, color='red', linestyle='--', label='converged at epoch ' + str(conv_A))
    axes[0].legend()
axes[0].set_title("dataset A (cov=I): misclassified per epoch")
axes[0].set_xlabel("epoch")
axes[0].set_ylabel("misclassified samples")

axes[1].plot(range(1, len(misc_B) + 1), misc_B, color='darkorange', linewidth=1.5) # misclass curve B
if conv_B:
    axes[1].axvline(conv_B, color='red', linestyle='--', label='converged at epoch ' + str(conv_B))
    axes[1].legend()
else:
    axes[1].set_title("dataset B (cov=3I): misclassified per epoch\n(Did Not Converge)", color='black')
axes[1].set_title("dataset B (cov=3I): misclassified per epoch")
axes[1].set_xlabel("epoch")
axes[1].set_ylabel("misclassified samples")

mtplot.tight_layout()
mtplot.show()

# plot decision boundary overlaid on train and test data
def plot_boundary(ax, X_data, y_data, w, b, title):
    colors = numpy.where(y_data == -1, 'steelblue', 'tomato')
    ax.scatter(X_data[:, 0], X_data[:, 1], c=colors, alpha=0.6, s=20, edgecolors='none') # scatter plot
    x1_range = numpy.linspace(X_data[:, 0].min() - 1, X_data[:, 0].max() + 1, 200)
    if abs(w[1]) > 1e-9:                          # avoid division by zero
        x2_boundary = -(w[0] * x1_range + b) / w[1] # decision boundary line
        ax.plot(x1_range, x2_boundary, 'k-', linewidth=2, label='decision boundary')
    ax.set_title(title)
    ax.set_xlabel("x1")
    ax.set_ylabel("x2")
    ax.legend(fontsize=8)

fig, axes = mtplot.subplots(2, 2, figsize=(12, 10))

plot_boundary(axes[0, 0], X_A_tr, y_A_tr, w_A, b_A, "dataset A - training data + boundary")
plot_boundary(axes[0, 1], X_A_te, y_A_te, w_A, b_A, "dataset A - test data + boundary")
plot_boundary(axes[1, 0], X_B_tr, y_B_tr, w_B, b_B, "dataset B - training data + boundary")
plot_boundary(axes[1, 1], X_B_te, y_B_te, w_B, b_B, "dataset B - test data + boundary")

mtplot.tight_layout()
mtplot.show()
